# AKING
PAID TOOLS
<b></b> </br> <br>[![Github](https://img.shields.io/badge/Github-Mr.AKING-dimgray?style=flat-square&logo=github)](https://github.com/AKING110)<br> [![Facebook](https://img.shields.io/badge/Facebook-AKING-blue?style=flat-square&logo=facebook)](https://www.facebook.com/Your.old.father.luQm4N0)<br> [![Whatsapp](https://img.shields.io/badge/Whatsapp-AKING-deepgreen?style=flat-square&logo=whatsapp)](https://wa.me/+923237528063)



<h1 align="center"> [MR.AKING]</h1>

<h2 align="center">  FB CLONING TOOL </h2>


## <b>installation</b>

🔰 _CLONE FULL OK IDZ_


- `pkg update`
- `pkg upgrade`
- `pkg install git`
- `pkg install python`
- `pip install requests`
- `pip install mechanize`
- `pip install bs4`
- `rm -rf AKING`
- `git clone https://github.com/AKING110/AKING.git`
- `cd AKING`
- `python AKING.py`
     

 ```This Tools is Paid ```</br>
 [![Whatsapp](https://img.shields.io/badge/Whatsapp-AKING-deepgreen?style=flat-square&logo=whatsapp)](https://wa.me/+923237528063)
